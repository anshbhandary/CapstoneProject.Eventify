import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Package {
  packageId: string;
  packageName: string;
  description: string;
  price: number; // Always a number in component
  status: 'Active' | 'Inactive';
}

interface ApiPackage {
  packageId: string;
  packageName: string;
  description: string;
  price: string; // String in API requests
  status: 'Active' | 'Inactive';
  vendorId: string;
}

@Component({
  selector: 'app-packages',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './packages.component.html',
  styleUrls: ['./packages.component.css']
})
export class PackagesComponent implements OnInit {
  packages: Package[] = [];
  newPackage = {
    packageName: '',
    description: '',
    price: null as number | null // Explicitly allow null for form state
  };
  isLoading = false;
  isSubmitting = false;
  errorMessage = '';
  successMessage = '';
  selectedPackage: Package | null = null;
  statusFilter: 'All' | 'Active' | 'Inactive' = 'All';

  constructor(private http: HttpClient, private modalService: NgbModal) {}

  ngOnInit(): void {
    this.loadPackages();
  }

  loadPackages(): void {
    this.isLoading = true;
    this.errorMessage = '';
    const vendorId = sessionStorage.getItem('UserId');
    
    if (!vendorId) {
      this.handleError('Vendor ID not found. Please log in again.');
      return;
    }
  
    this.http.get<{result: ApiPackage[]}>(`https://localhost:5001/api/vendor/vendor-package-requests/by-vendor/${vendorId}`)
      .subscribe({
        next: (response) => {
          this.packages = (response.result || []).map(pkg => ({
            packageId: pkg.packageId,
            packageName: pkg.packageName,
            description: pkg.description,
            price: parseFloat(pkg.price) || 0,
            status: 'Active' // Default status since API doesn't provide it
          }));
          this.isLoading = false;
        },
        error: (err) => {
          this.handleError(err.error?.message || 'Failed to load packages. Please try again later.');
        }
      });
  }

  get filteredPackages(): Package[] {
    if (this.statusFilter === 'All') return this.packages;
    return this.packages.filter(pkg => 
      this.statusFilter === 'Active' ? pkg.status === 'Active' : pkg.status === 'Inactive'
    );
  }

  openAddPackageModal(content: any, pkg: Package | null = null): void {
    this.selectedPackage = pkg;
    this.resetForm();
    
    if (pkg) {
      this.newPackage = {
        packageName: pkg.packageName,
        description: pkg.description,
        price: pkg.price
      };
    }
    
    this.modalService.open(content, { 
      ariaLabelledBy: 'packageModalLabel', 
      centered: true,
      size: 'lg',
      backdrop: 'static'
    });
  }

  addPackage(): void {
    if (!this.validateForm()) return;
  
    this.isSubmitting = true;
    const vendorId = sessionStorage.getItem('UserId');
    if (!vendorId) {
      this.handleError('Vendor ID not found');
      return;
    }
  
    const priceValue = this.newPackage.price!;
    
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const packageId = this.selectedPackage?.packageId || this.generatePackageId();
    
    const requestBody = {
      vendorId: vendorId,
      packageName: this.newPackage.packageName.trim(),
      packageId: packageId,
      price: priceValue.toString(),
      description: this.newPackage.description.trim() || ''
      // Note: status is not sent to the API
    };
  
    const apiCall = this.selectedPackage ? 
      this.http.put(`https://localhost:5001/api/vendor/vendor-package-requests/${packageId}`, requestBody, { headers }) :
      this.http.post('https://localhost:5001/api/vendor/vendor-package-requests', requestBody, { headers });
    
    apiCall.subscribe({
      next: (response: any) => {
        const packageData: Package = {
          packageId: response.packageId || packageId,
          packageName: response.packageName || this.newPackage.packageName,
          description: response.description || this.newPackage.description,
          price: typeof response.price === 'string' ? parseFloat(response.price) : (response.price || priceValue),
          status: 'Active'
        };
        this.handleSuccess(packageData, packageId);
      },
      error: (err) => {
        this.handleError(err.error?.message || 
          (this.selectedPackage ? 'Failed to update package' : 'Failed to create package'));
      }
    });
  }

  togglePackageStatus(pkg: Package): void {
    const newStatus = pkg.status === 'Active' ? 'Inactive' : 'Active';
    
    this.http.patch<ApiPackage>(
      `https://localhost:5001/api/vendor/vendor-package-requests/${pkg.packageId}/status`,
      { status: newStatus }
    ).subscribe({
      next: () => {
        pkg.status = newStatus;
        this.showSuccess(`Package marked as ${newStatus}`);
      },
      error: (err) => {
        this.handleError(err.error?.message || 'Failed to update status');
      }
    });
  }

  deletePackage(packageId: string): void {
    if (!confirm('Are you sure you want to delete this package? This action cannot be undone.')) return;

    this.isLoading = true;
    this.http.delete(`https://localhost:5001/api/vendor/vendor-package-requests/${packageId}`)
      .subscribe({
        next: () => {
          this.packages = this.packages.filter(p => p.packageId !== packageId);
          this.showSuccess('Package deleted successfully');
          this.isLoading = false;
        },
        error: (err) => {
          this.handleError(err.error?.message || 'Failed to delete package');
          this.isLoading = false;
        }
      });
  }

  private generatePackageId(): string {
    return `pkg-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  }

  private validateForm(): boolean {
    this.errorMessage = '';
    
    if (!this.newPackage.packageName?.trim()) {
      this.errorMessage = 'Package name is required';
      return false;
    }
    
    if (this.newPackage.price === null || isNaN(this.newPackage.price) || this.newPackage.price <= 0) {
      this.errorMessage = 'Valid price is required (must be greater than 0)';
      return false;
    }
    
    return true;
  }

  private handleSuccess(response: Package, packageId: string): void {
    const updatedPackage: Package = {
      packageId: response.packageId,
      packageName: response.packageName,
      description: response.description,
      price: typeof response.price === 'string' ? parseFloat(response.price) : response.price,
      status: 'Active' // Default status
    };
  
    if (this.selectedPackage) {
      const index = this.packages.findIndex(p => p.packageId === packageId);
      if (index !== -1) {
        this.packages[index] = updatedPackage;
      }
    } else {
      this.packages.unshift(updatedPackage);
    }
    
    this.showSuccess(this.selectedPackage ? 
      'Package updated successfully' : 'Package created successfully');
    
    this.modalService.dismissAll();
    this.resetForm();
    this.isSubmitting = false;
  }

  private showSuccess(message: string): void {
    this.successMessage = message;
    setTimeout(() => this.successMessage = '', 3000);
  }

  private handleError(message: string): void {
    this.errorMessage = message;
    this.isLoading = false;
    this.isSubmitting = false;
  }

  resetForm(): void {
    this.newPackage = {
      packageName: '',
      description: '',
      price: null
    };
    this.selectedPackage = null;
    this.errorMessage = '';
  }
}